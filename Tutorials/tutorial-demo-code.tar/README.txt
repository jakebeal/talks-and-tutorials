This collection of demo code is intended to accompany various Proto
tutorials.  The "*-sequence.proto" files contain invocations of the
MIT Proto simulator, to be pasted into the command line and executed
in sequence.  The other .proto files in the directory are functions
used by these invocations.
