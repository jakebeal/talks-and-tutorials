The files in this directory comprise a demonstration of how the
amorphous medium abstraction, as implemented in Proto, can allow safe,
terse construction of complex swarm behaviors, as well as the
modulation of behaviors.

To run the demonstrations, evaluate the lines beginning with "proto"
in the file "fss12-demo-sequence.proto".  

The other .proto files are used by the demonstration commands in this
file.  In many cases their code is shown in the demo file for
pedagogical reasons: changing that code will have no effect; you must
change it in the other .proto files.

These files have been constructed and tested using:
   Proto release 7, paleocompiler
